/*
 * Prelab5.h
 *
 * Created: 4/10/2025 7:19:48 PM
 *  Author: joshu
 */ 


#ifndef Prelab5_H
#define Prelab5_H

#include <avr/io.h>

void PWM_init();
void PWM_setAngle(uint16_t angle);

#endif