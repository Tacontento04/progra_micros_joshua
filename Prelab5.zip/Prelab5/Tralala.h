/*
 * Tralala.h
 *
 * Created: 4/10/2025 11:35:17 PM
 *  Author: joshu
 */ 


#ifndef TRALALA_H_
#define TRALALA_H_
#include <avr/io.h>

void PWM_init2();
void PWM_setAngle2(uint16_t duty);

#endif /* TRALALA_H_ */