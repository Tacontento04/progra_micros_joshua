//**********************************************************
//Universidad del Valle de Guatemala
//IE2023 : Programaci�n de Microcontroladores
//Test.asm
//
//Autor: Joshua V�squez
//Proyecto: LAB5
//Hardware: ATMega328P
//Creado: 4/10/25         
//Modificado :
//Descripcion: Servo Motorsss



//**************************************
//ENCABEZADO
//******************************************
#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include "Prelab5.h"
#include "Tralala.h"

volatile uint8_t mux_state = 0;
volatile  state = 0; 

void ADC_init() {
	ADMUX = 0;
	ADMUX = (1 << REFS0); // Poner los 5V como referencia
	ADMUX	|= (1 << MUX2) | (1<< MUX1); //Seleccionar el ADC6
	ADCSRA = (1 << ADEN) | (1 << ADPS1) | (1 << ADPS0); // velodidad de muestreo de factor de division de 8
}

void ADC_init2() {  // correcto
	ADMUX = 0;
	ADMUX = (1 << REFS0); // Poner los 5V como referencia (AVcc)
	ADMUX |= (1 << MUX1) | (1 << MUX0); // Seleccionar el ADC3 (PC3)
	ADCSRA = (1 << ADEN) | (1 << ADPS1) | (1 << ADPS0); //  velocidad de muestreo de 8
	
}

uint16_t ADC_read() {
	ADCSRA |= (1 << ADSC); // Iniciar conversi�n
	while (ADCSRA & (1 << ADSC)); // Esperar a que termine
	return ADC; // Leer el resultado
}



int main(void) {

	while (1) {
		//servo 1
		ADC_init();
		PWM_init();
		uint16_t adc = ADC_read(); // 0 - 1023
		uint16_t angle = (adc * 3500.0/1023.0) + 1000; // Mapear a 0-180 grados
		PWM_setAngle(angle);
		_delay_ms(10);
		//servo 2
		ADC_init2();
		PWM_init2();
		uint16_t adcarry = ADC_read(); // 0 - 1023
		uint16_t duty = (adcarry * 180.0/1023.0); // Mapear a 0-180 grados
		PWM_setDuty2(duty);
		_delay_ms(10);
	}
}